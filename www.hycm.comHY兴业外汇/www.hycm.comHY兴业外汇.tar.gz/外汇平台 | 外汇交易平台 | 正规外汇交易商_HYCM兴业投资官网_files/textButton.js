try{document.open();}catch(e){;}
var live800_companyID="299276";
var live800_protocol="http:";
var live800_isMobile="0";
var jsessionId = ";jsessionid=77B5F5E87BE229BAB4DD004821C07DC5";
try{
if(navigator.cookieEnabled && navigator.platform !== "iPhone" && navigator.platform !== "iPad"){jsessionId = "";}
}catch(e){}
var enterurl = null;
enterurl="https%3A%2F%2Fwww.hycm.com%2Fcn%2F";
var isOldSkin=false;
var server_prefix_list=['https://st8.live800.com/live800','https://st.live800.com/live800','https://st10.live800.com/live800','https://st16.live800.com/live800'];
var isNeedCheckDomainBinding=false;
var globalWindowAttribute='toolbar=0,scrollbars=0,location=0,menubar=0,resizable=1,width=920,height=620';
live800_chatVersion="5";
jid="1221985430";
var live800_baseUrl="chat8.live800.com";
var live800_baseHtmlUrl="chat8.live800.com";
var live800_baseWebApp="/live800";
var live800_baseChatHtmlDir="/chatClient";
live800_Language="zh";
live800_configID="149790";
live800_codeType="custom";
live800_configContent="live800_text=%252e&live800_switch=0";

document.write("<scr"+"ipt language=\"javascript\" src=\"https://st10.live800.com/live800/chatClient/textStatic.js\"></scr"+"ipt>");