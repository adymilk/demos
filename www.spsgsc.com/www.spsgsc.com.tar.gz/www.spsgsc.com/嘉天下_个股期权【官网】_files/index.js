$('.index_banner .flexslider').flexslider({
	animation: "fade",
	directionNav: false
});

$('.partners .flexslider').flexslider({
    animation: "slide"
});