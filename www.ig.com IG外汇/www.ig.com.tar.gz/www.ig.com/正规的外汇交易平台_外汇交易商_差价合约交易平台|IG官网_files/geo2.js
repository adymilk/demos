(function(){
  window['optimizely'] = window['optimizely'] || [];
  window['optimizely'].push(['activateGeoDelayedExperiments', {
    'location':{
      'city': "HEFEI",
      'continent': "AS",
      'country': "CN",
      'region': "AH"
    },
    'ip':"114.102.138.14"
  }]);
})
//
()

;